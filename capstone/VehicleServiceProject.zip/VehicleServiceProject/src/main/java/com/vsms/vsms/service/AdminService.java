package com.vsms.vsms.service;

import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.entity.Vehicle;
import com.vsms.vsms.repository.ServiceBookingRepository;
import com.vsms.vsms.repository.UserRepository;
import com.vsms.vsms.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class AdminService {

    private final UserRepository userRepository;
    private final VehicleRepository vehicleRepository;
    private final ServiceBookingRepository bookingRepository;

    public AdminService(UserRepository userRepository, 
                        VehicleRepository vehicleRepository, 
                        ServiceBookingRepository bookingRepository) {
        this.userRepository = userRepository;
        this.vehicleRepository = vehicleRepository;
        this.bookingRepository = bookingRepository;
    }

    // --- Dashboard Stats (Strict Methods) ---
    public long getTotalUsers() {
        return userRepository.count();
    }

    public long getTotalVehicles() {
        return vehicleRepository.count();
    }

    public long getTotalBookings() {
        return bookingRepository.count();
    }

    public long getPendingBookings() {
        return countBookingsByStatus("PENDING");
    }

    public long getApprovedBookings() {
        return countBookingsByStatus("APPROVED");
    }

    public long getCompletedBookings() {
        return countBookingsByStatus("COMPLETED");
    }

    private long countBookingsByStatus(String status) {
        // Fallback filtering since custom repository methods might not exist
        return bookingRepository.findAll().stream()
                .filter(b -> b.getStatus() != null && b.getStatus().equalsIgnoreCase(status))
                .count();
    }

    // --- User Management ---
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    // --- Vehicle Management ---
    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    @Transactional
    public void deleteVehicle(Long vehicleId) {
        vehicleRepository.deleteById(vehicleId);
    }

    // --- Booking Management ---
    public List<ServiceBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<ServiceBooking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Transactional
    public void approveBooking(Long id) {
        bookingRepository.findById(id).ifPresent(booking -> {
            booking.setStatus("APPROVED");
            bookingRepository.save(booking);
        });
    }

    @Transactional
    public void completeBooking(Long id) {
        bookingRepository.findById(id).ifPresent(booking -> {
            booking.setStatus("COMPLETED");
            bookingRepository.save(booking);
        });
    }

    @Transactional
    public void updateBookingPrice(Long id, Double price) {
        bookingRepository.findById(id).ifPresent(booking -> {
            booking.setPrice(price);
            bookingRepository.save(booking);
        });
    }

}

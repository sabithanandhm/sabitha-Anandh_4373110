package com.vsms.vsms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vsms.vsms.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmail(String email);

    // ✅ ADD THIS
    User findByUsername(String username);
}

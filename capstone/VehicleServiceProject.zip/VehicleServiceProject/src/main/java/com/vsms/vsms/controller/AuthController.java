package com.vsms.vsms.controller;

import com.vsms.vsms.entity.Role;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.repository.RoleRepository;
import com.vsms.vsms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashSet;
import java.util.Set;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String password) {

        if (userRepository.findByEmail(email) != null) {
            return "redirect:/register?error";
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setUsername(email); // ✅ username required
        user.setPassword(passwordEncoder.encode(password));
        user.setEnabled(true); // ✅ Explicitly enable user

        // 🔥 FIX: ROLE ASSIGNMENT (CORRECT WAY)
        Role userRole = roleRepository.findByName("ROLE_USER")
                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));

        Set<Role> roles = new HashSet<>();
        roles.add(userRole);

        user.setRoles(roles);

        userRepository.save(user);

        return "redirect:/login?registered";
    }
}

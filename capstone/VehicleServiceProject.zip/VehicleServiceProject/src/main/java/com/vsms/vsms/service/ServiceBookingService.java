package com.vsms.vsms.service;

import java.util.List;
import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.entity.User;

public interface ServiceBookingService {

    void saveBooking(ServiceBooking booking);

    List<ServiceBooking> getBookingsByUser(User user);

    // 👇 THIS IS IMPORTANT
    ServiceBooking getBookingById(Long id);

    void deleteBooking(Long id);

    void updateBookingStatus(Long id, String status);

    List<ServiceBooking> getAllBookings();
}


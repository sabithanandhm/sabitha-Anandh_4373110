package com.vsms.vsms.service;

import java.util.List;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.entity.Vehicle;

public interface VehicleService {
    List<Vehicle> getVehiclesForUser(User user);
    void saveVehicle(Vehicle vehicle);
    Vehicle getVehicleById(Long id);
    void deleteVehicle(Long id);
}

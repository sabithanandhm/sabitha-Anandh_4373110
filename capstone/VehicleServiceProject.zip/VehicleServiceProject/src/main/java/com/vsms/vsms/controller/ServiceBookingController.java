package com.vsms.vsms.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.service.ServiceBookingService;
import com.vsms.vsms.service.UserService;
import com.vsms.vsms.service.PdfService;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
public class ServiceBookingController {

    private final ServiceBookingService bookingService;
    private final UserService userService;
    private final com.vsms.vsms.repository.VehicleRepository vehicleRepository;
    private final PdfService pdfService;

    public ServiceBookingController(ServiceBookingService bookingService,
                                    UserService userService,
                                    com.vsms.vsms.repository.VehicleRepository vehicleRepository,
                                    PdfService pdfService) {
        this.bookingService = bookingService;
        this.userService = userService;
        this.vehicleRepository = vehicleRepository;
        this.pdfService = pdfService;
    }

    // ---------------- BOOK SERVICE PAGE ----------------
    @GetMapping("/bookService")
    public String bookServiceForm(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        
        String email = principal.getName();
        User user = userService.getUserByEmail(email);
        
        model.addAttribute("booking", new ServiceBooking());
        
        if (user != null) {
            List<com.vsms.vsms.entity.Vehicle> userVehicles = vehicleRepository.findByUser(user);
            model.addAttribute("userVehicles", userVehicles);
        }
        
        return "book-service";
    }

    // ---------------- SAVE BOOKING ----------------
    @PostMapping("/saveServiceBooking")
    public String saveBooking(ServiceBooking booking, Principal principal) {

        if (principal == null) {
            return "redirect:/login";
        }

        String email = principal.getName();
        User user = userService.getUserByEmail(email);

        if (user == null) {
            return "redirect:/login";
        }

        // Find Vehicle by Number
        com.vsms.vsms.entity.Vehicle vehicle = 
            vehicleRepository.findFirstByVehicleNumber(booking.getVehicleNumber());

        if (vehicle == null) {
            // Auto-register new vehicle
            vehicle = new com.vsms.vsms.entity.Vehicle();
            vehicle.setVehicleNumber(booking.getVehicleNumber());
            vehicle.setOwnerName(user.getName()); // Use logged-in user's name
            vehicle.setVehicleType("Auto-Added");
            vehicle.setPrice(0.0); // Default price
            vehicle.setUser(user); // Map to user
            vehicleRepository.save(vehicle);
        }

        booking.setVehicle(vehicle);
        booking.setUser(user);
        booking.setStatus("PENDING");
        
        // AUTO-FETCH PRICE FROM VEHICLE (REQUIREMENT #4 & #5)
        booking.setPrice(vehicle.getPrice()); 

        bookingService.saveBooking(booking);
        return "redirect:/myBookings";
    }

    // ---------------- MY BOOKINGS (STRICTLY USER ONLY) ----------------
    @GetMapping("/myBookings")
    public String myBookings(Model model, Principal principal) {

        if (principal == null) {
            return "redirect:/login";
        }

        String email = principal.getName();
        User user = userService.getUserByEmail(email);

        if (user == null) {
            model.addAttribute("bookings", List.of());
            return "my-bookings";
        }

        // 1. Determine if this is an Admin (for UI buttons only)
        boolean isAdmin = "ADMIN".equalsIgnoreCase(user.getRole());
        model.addAttribute("isAdmin", isAdmin);

        // 2. FETCH ONLY THIS USER'S BOOKINGS
        // Even if Admin, My Bookings page shows THEIR personal bookings.
        // Admin Management is done on a separate Admin page.
        List<ServiceBooking> bookings = bookingService.getBookingsByUser(user);

        model.addAttribute("bookings", bookings);

        // 3. Calculate Stats based on specific user's bookings
        long totalBookings = bookings.size();
        long pendingBookings = bookings.stream().filter(b -> "PENDING".equalsIgnoreCase(b.getStatus())).count();
        long approvedBookings = bookings.stream().filter(b -> "APPROVED".equalsIgnoreCase(b.getStatus())).count();
        long completedBookings = bookings.stream().filter(b -> "COMPLETED".equalsIgnoreCase(b.getStatus())).count();

        model.addAttribute("totalBookings", totalBookings);
        model.addAttribute("pendingBookings", pendingBookings);
        model.addAttribute("approvedBookings", approvedBookings);
        model.addAttribute("completedBookings", completedBookings);

        return "my-bookings";
    }

    // ---------------- SINGLE BOOKING ----------------
    @GetMapping("/booking/{id}")
    public String bookingDetails(@PathVariable Long id,
                                 Model model,
                                 Principal principal) {

        if (principal == null) {
            return "redirect:/login";
        }

        ServiceBooking booking = bookingService.getBookingById(id);

        if (booking == null) {
            return "redirect:/myBookings";
        }
        
        // Optional: Check if booking belongs to principal user
        // if (!booking.getUser().getEmail().equals(principal.getName()) && !isAdmin) ...

        model.addAttribute("booking", booking);
        return "booking-details";
    }

    // ---------------- DOWNLOAD RECEIPT ----------------
    @GetMapping("/booking/{id}/receipt")
    public void downloadReceipt(@PathVariable Long id, HttpServletResponse response) throws IOException {
        ServiceBooking booking = bookingService.getBookingById(id);
        if (booking == null) {
            response.sendRedirect("/myBookings");
            return;
        }

        response.setContentType("application/pdf");
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=receipt_" + id + ".pdf";
        response.setHeader(headerKey, headerValue);

        pdfService.generateBookingReceipt(booking, response);
    }

    // ---------------- DELETE BOOKING (ADMIN ONLY) ----------------
    @GetMapping("/deleteBooking/{id}")
    public String deleteBooking(@PathVariable Long id, Principal principal) {
        if (principal == null) return "redirect:/login";
        User user = userService.getUserByEmail(principal.getName());
        
        if (!"ADMIN".equalsIgnoreCase(user.getRole())) {
             return "redirect:/access-denied"; 
        }

        bookingService.deleteBooking(id);
        return "redirect:/myBookings";
    }

    // ---------------- STATUS UPDATES (ADMIN ONLY) ----------------
    @GetMapping("/approveBooking/{id}")
    public String approveBooking(@PathVariable Long id, Principal principal) {
        if (principal == null) return "redirect:/login";
        User user = userService.getUserByEmail(principal.getName());

        if (!"ADMIN".equalsIgnoreCase(user.getRole())) {
             return "redirect:/myBookings"; 
        }

        bookingService.updateBookingStatus(id, "APPROVED");
        return "redirect:/myBookings";
    }

    @GetMapping("/completeBooking/{id}")
    public String completeBooking(@PathVariable Long id, Principal principal) {
        if (principal == null) return "redirect:/login";
        User user = userService.getUserByEmail(principal.getName());

        if (!"ADMIN".equalsIgnoreCase(user.getRole())) {
             return "redirect:/myBookings"; 
        }

        bookingService.updateBookingStatus(id, "COMPLETED");
        return "redirect:/myBookings";
    }
}

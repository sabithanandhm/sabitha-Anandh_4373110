package com.vsms.vsms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.vsms.vsms.entity.Vehicle;
import com.vsms.vsms.repository.VehicleRepository;

@Controller
public class VehicleController {

    private final com.vsms.vsms.service.VehicleService vehicleService;
    private final com.vsms.vsms.service.UserService userService;

    public VehicleController(com.vsms.vsms.service.VehicleService vehicleService,
                             com.vsms.vsms.service.UserService userService) {
        this.vehicleService = vehicleService;
        this.userService = userService;
    }

    // LIST
    @GetMapping("/vehicles")
    public String viewVehicles(Model model, java.security.Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        String email = principal.getName();
        com.vsms.vsms.entity.User user = userService.getUserByEmail(email);

        // Service handles the Admin vs User logic
        List<Vehicle> list = vehicleService.getVehiclesForUser(user);
        
        model.addAttribute("vehicles", list);
        return "vehicle-list";
    }

    // ADD FORM
    @GetMapping({"/addVehicleForm", "/addVehicle"})
    public String addVehicleForm(Model model, java.security.Principal principal) {
        boolean isAdmin = false;
        if (principal != null) {
            String email = principal.getName();
            com.vsms.vsms.entity.User user = userService.getUserByEmail(email);
            if (user != null) {
                isAdmin = "ADMIN".equalsIgnoreCase(user.getRole());
            }
        }
        model.addAttribute("isAdmin", isAdmin);
        model.addAttribute("vehicle", new Vehicle());
        return "add-vehicle";
    }

    // SAVE
    @PostMapping("/saveVehicle")
    public String saveVehicle(@ModelAttribute("vehicle") Vehicle vehicle, java.security.Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        
        String email = principal.getName();
        com.vsms.vsms.entity.User user = userService.getUserByEmail(email);
        boolean isAdmin = (user != null && "ADMIN".equalsIgnoreCase(user.getRole()));

        if (vehicle.getId() != null) {
            Vehicle existing = vehicleService.getVehicleById(vehicle.getId());
            if (existing != null) {
                // Price is NOT managed in this form anymore
                vehicle.setPrice(existing.getPrice());
                
                // Ensure user mapping doesn't break if already assigned
                if (vehicle.getUser() == null) {
                    vehicle.setUser(existing.getUser());
                }
            }
        } else {
            // New vehicle, default price to 0.0
            vehicle.setPrice(0.0);
            vehicle.setUser(user);
        }
        
        vehicleService.saveVehicle(vehicle);
        return "redirect:/vehicles";
    }

    // EDIT
    @GetMapping("/editVehicle/{id}")
    public String editVehicle(@PathVariable Long id, Model model, java.security.Principal principal) {
        boolean isAdmin = false;
        if (principal != null) {
            String email = principal.getName();
            com.vsms.vsms.entity.User user = userService.getUserByEmail(email);
            if (user != null) {
                isAdmin = "ADMIN".equalsIgnoreCase(user.getRole());
            }
        }
        model.addAttribute("isAdmin", isAdmin);
        Vehicle vehicle = vehicleService.getVehicleById(id);
        model.addAttribute("vehicle", vehicle);
        return "add-vehicle";
    }

    // DELETE
    @GetMapping("/deleteVehicle/{id}")
    public String deleteVehicle(@PathVariable Long id) {
        vehicleService.deleteVehicle(id);
        return "redirect:/vehicles";
    }
}

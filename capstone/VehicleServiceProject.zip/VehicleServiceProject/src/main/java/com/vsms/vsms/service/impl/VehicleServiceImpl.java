package com.vsms.vsms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vsms.vsms.entity.User;
import com.vsms.vsms.entity.Vehicle;
import com.vsms.vsms.repository.VehicleRepository;
import com.vsms.vsms.service.VehicleService;

@Service
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository repository;

    public VehicleServiceImpl(VehicleRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Vehicle> getVehiclesForUser(User user) {
        // ADMIN Logic: See ALL vehicles
        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            return repository.findAll();
        }
        // USER Logic: See ONLY their own vehicles
        return repository.findByUser(user);
    }

    @Override
    public void saveVehicle(Vehicle vehicle) {
        repository.save(vehicle);
    }

    @Override
    public Vehicle getVehicleById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void deleteVehicle(Long id) {
        repository.deleteById(id);
    }
}

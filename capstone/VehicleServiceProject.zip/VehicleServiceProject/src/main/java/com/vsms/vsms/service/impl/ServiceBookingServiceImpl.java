package com.vsms.vsms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.repository.ServiceBookingRepository;
import com.vsms.vsms.service.ServiceBookingService;

@Service
public class ServiceBookingServiceImpl implements ServiceBookingService {

    private final ServiceBookingRepository repository;

    public ServiceBookingServiceImpl(ServiceBookingRepository repository) {
        this.repository = repository;
    }

    @Override
    public void saveBooking(ServiceBooking booking) {
        repository.save(booking);
    }

    @Override
    public List<ServiceBooking> getBookingsByUser(User user) {
        return repository.findByUser(user);
    }

    @Override
    public ServiceBooking getBookingById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void deleteBooking(Long id) {
        repository.deleteById(id);
    }

    @Override
    public void updateBookingStatus(Long id, String status) {
        ServiceBooking booking = repository.findById(id).orElse(null);
        if (booking != null) {
            booking.setStatus(status);
            repository.save(booking);
        }
    }

    @Override
    public List<ServiceBooking> getAllBookings() {
        return repository.findAll();
    }
}

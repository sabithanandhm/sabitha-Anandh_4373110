package com.vsms.vsms.controller.admin;

import com.vsms.vsms.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminDashboardController {

    private final AdminService adminService;

    public AdminDashboardController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalUsers", adminService.getTotalUsers());
        model.addAttribute("totalVehicles", adminService.getTotalVehicles());
        model.addAttribute("totalBookings", adminService.getTotalBookings());
        model.addAttribute("pendingBookings", adminService.getPendingBookings());
        model.addAttribute("approvedBookings", adminService.getApprovedBookings());
        model.addAttribute("completedBookings", adminService.getCompletedBookings());
        return "admin/admin-dashboard";
    }
}

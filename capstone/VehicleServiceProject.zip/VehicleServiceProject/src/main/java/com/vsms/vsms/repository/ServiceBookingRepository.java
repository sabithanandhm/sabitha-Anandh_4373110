package com.vsms.vsms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.entity.User;

public interface ServiceBookingRepository
        extends JpaRepository<ServiceBooking, Long> {

    List<ServiceBooking> findByUser(User user);
}

package com.vsms.vsms.config;

import com.vsms.vsms.entity.Role;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.repository.RoleRepository;
import com.vsms.vsms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        
        // 1. Create Roles if not exist
        createRoleIfNotFound("ROLE_ADMIN");
        createRoleIfNotFound("ROLE_USER");

        // 2. Create Admin User if not exists
        if (userRepository.findByEmail("admin@vsms.com") == null) {
            User admin = new User();
            admin.setName("Super Admin");
            admin.setEmail("admin@vsms.com");
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEnabled(true);

            Role adminRole = roleRepository.findByName("ROLE_ADMIN").get();
            Set<Role> roles = new HashSet<>();
            roles.add(adminRole);
            admin.setRoles(roles);

            userRepository.save(admin);
            System.out.println("✅ Default Admin User Created: admin@vsms.com / admin123");
        }

        // 3. Fix: Enable all existing users (Migrate legacy data)
        userRepository.findAll().forEach(user -> {
            if (!user.isEnabled()) {
                user.setEnabled(true);
                userRepository.save(user);
                System.out.println("✅ Enabled User: " + user.getEmail());
            }
        });
    }

    private void createRoleIfNotFound(String name) {
        if (roleRepository.findByName(name).isEmpty()) {
            Role role = new Role();
            role.setName(name);
            roleRepository.save(role);
        }
    }
}

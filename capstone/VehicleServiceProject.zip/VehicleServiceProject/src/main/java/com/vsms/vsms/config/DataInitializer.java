package com.vsms.vsms.config;

import com.vsms.vsms.entity.Role;
import com.vsms.vsms.entity.User;
import com.vsms.vsms.repository.RoleRepository;
import com.vsms.vsms.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Collections;
import java.util.HashSet;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner initData(UserRepository userRepository, 
                                      RoleRepository roleRepository, 
                                      PasswordEncoder passwordEncoder) {
        return args -> {
            
            // 1. Ensure Roles Exist
            createRoleIfNotFound(roleRepository, "ROLE_ADMIN");
            createRoleIfNotFound(roleRepository, "ROLE_USER");

            // 2. Create Default Admin if not exists
            if (userRepository.findByEmail("admin@vsms.com") == null) {
                User admin = new User();
                admin.setName("Admin User");
                admin.setEmail("admin@vsms.com");
                admin.setUsername("admin@vsms.com");
                admin.setPassword(passwordEncoder.encode("admin123"));
                
                Role adminRole = roleRepository.findByName("ROLE_ADMIN").get();
                admin.setRoles(new HashSet<>(Collections.singletonList(adminRole)));
                
                userRepository.save(admin);
                System.out.println("✅ Default Admin created: admin@vsms.com / admin123");
            }

            // 3. Create Default User if not exists
            if (userRepository.findByEmail("user@vsms.com") == null) {
                User user = new User();
                user.setName("Normal User");
                user.setEmail("user@vsms.com");
                user.setUsername("user@vsms.com");
                user.setPassword(passwordEncoder.encode("user123"));

                Role userRole = roleRepository.findByName("ROLE_USER").get();
                user.setRoles(new HashSet<>(Collections.singletonList(userRole)));

                userRepository.save(user);
                System.out.println("✅ Default User created: user@vsms.com / user123");
            }
        };
    }

    private void createRoleIfNotFound(RoleRepository roleRepository, String roleName) {
        if (roleRepository.findByName(roleName).isEmpty()) {
            Role role = new Role();
            role.setName(roleName);
            roleRepository.save(role);
        }
    }
}

package com.vsms.vsms.entity;

import jakarta.persistence.*;
import java.util.Set;
import java.util.HashSet;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(unique = true, nullable = false)
    private String email;

    private String password;

    private String name;
    
    @Column(nullable = false)
    private boolean enabled = true; // Default to enabled

    // 🔥 ROLE BASED LOGIN (ADMIN / USER)
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles;

    // ✅ NO-ARGS CONSTRUCTOR (MANDATORY)
    public User() {
    }

    // ---------- GETTERS & SETTERS ----------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    // Helper methods for role string handling
    public String getRole() {
        if (roles != null && !roles.isEmpty()) {
            return roles.iterator().next().getName();
        }
        return null;
    }

    public void setRole(String roleName) {
        if (roleName == null) {
            this.roles = null;
            return;
        }
        Role role = new Role();
        role.setName(roleName);
        this.roles = new HashSet<>();
        this.roles.add(role);
    }
}

package com.vsms.vsms.service;

import com.vsms.vsms.entity.ServiceBooking;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface PdfService {
    void generateBookingReceipt(ServiceBooking booking, HttpServletResponse response) throws IOException;
}

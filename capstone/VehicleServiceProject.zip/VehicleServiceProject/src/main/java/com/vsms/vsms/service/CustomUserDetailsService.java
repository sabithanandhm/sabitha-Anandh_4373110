package com.vsms.vsms.service;

import com.vsms.vsms.entity.User;
import com.vsms.vsms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        // Lookup user by email (using email as username)
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new UsernameNotFoundException("User not found with email: " + email);
        }

        // Determine Authority/Role
        // Fallback to "ROLE_USER" if role is missing/null to prevent login errors for legacy data
        String role = user.getRole();
        if (role == null || role.trim().isEmpty()) {
            role = "ROLE_USER"; 
        }

        // Return Spring Security User object
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .authorities(role)
                .disabled(!user.isEnabled()) // Check if user is enabled
                .build();
    }
}

package com.vsms.vsms.controller.admin;

import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin/bookings")
public class AdminBookingController {

    private final AdminService adminService;

    public AdminBookingController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping
    public String getAllBookings(Model model) {
        List<ServiceBooking> bookings = adminService.getAllBookings();
        model.addAttribute("bookings", bookings);
        return "admin/admin-bookings";
    }

    @GetMapping("/{id}")
    public String getBookingDetails(@PathVariable Long id, Model model) {
        Optional<ServiceBooking> booking = adminService.getBookingById(id);
        if (booking.isPresent()) {
            model.addAttribute("booking", booking.get());
            return "admin/admin-booking-details";
        }
        return "redirect:/admin/bookings";
    }

    @PostMapping("/approve")
    public String approveBooking(@RequestParam("id") Long id) {
        adminService.approveBooking(id);
        return "redirect:/admin/bookings";
    }

    @PostMapping("/complete")
    public String completeBooking(@RequestParam("id") Long id) {
        adminService.completeBooking(id);
        return "redirect:/admin/bookings";
    }

    @PostMapping("/updatePrice")
    public String updatePrice(@RequestParam("id") Long id, 
                             @RequestParam("price") Double price,
                             org.springframework.web.servlet.mvc.support.RedirectAttributes redirectAttributes) {
        if (price == null || price <= 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "Price must be greater than zero.");
            return "redirect:/admin/bookings/" + id;
        }
        adminService.updateBookingPrice(id, price);
        redirectAttributes.addFlashAttribute("successMessage", "Price updated successfully!");
        return "redirect:/admin/bookings/" + id;
    }
}

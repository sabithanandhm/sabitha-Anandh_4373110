package com.vsms.vsms.service.impl;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.vsms.vsms.entity.ServiceBooking;
import com.vsms.vsms.service.PdfService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.IOException;

@Service
public class PdfServiceImpl implements PdfService {

    @Override
    public void generateBookingReceipt(ServiceBooking booking, HttpServletResponse response) throws IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();

        // Fonts
        Font fontTitle = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        fontTitle.setSize(18);
        fontTitle.setColor(Color.BLUE);

        Font fontHeader = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        fontHeader.setSize(12);

        Font fontCell = FontFactory.getFont(FontFactory.HELVETICA);
        fontCell.setSize(12);

        // Title
        Paragraph title = new Paragraph("Vehicle Service Receipt", fontTitle);
        title.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph(" ")); // Spacer

        // Table
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);

        addCell(table, "Booking ID", fontHeader);
        addCell(table, String.valueOf(booking.getId()), fontCell);

        addCell(table, "Service Date", fontHeader);
        addCell(table, booking.getPreferredDate() != null ? booking.getPreferredDate().toString() : "N/A", fontCell);

        addCell(table, "Booking Status", fontHeader);
        addCell(table, booking.getStatus(), fontCell);

        addCell(table, "Vehicle Number", fontHeader);
        addCell(table, booking.getVehicle() != null ? booking.getVehicle().getVehicleNumber() : "N/A", fontCell);

        addCell(table, "Service Type", fontHeader);
        addCell(table, booking.getServiceType(), fontCell);

        addCell(table, "Service Price", fontHeader);
        String priceStr = booking.getPrice() != null ? "$" + booking.getPrice() : "Pending";
        addCell(table, priceStr, fontCell);

        document.add(table);

        document.close();
    }

    private void addCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(8);
        table.addCell(cell);
    }
}

package com.vsms.vsms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vsms.vsms.entity.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    Vehicle findFirstByVehicleNumber(String vehicleNumber);

    java.util.List<Vehicle> findByOwnerName(String ownerName);
    
    java.util.List<Vehicle> findByUser(com.vsms.vsms.entity.User user);
}

package com.vsms.vsms.controller.admin;

import com.vsms.vsms.entity.Vehicle;
import com.vsms.vsms.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/admin/vehicles")
public class AdminVehicleController {

    private final AdminService adminService;

    public AdminVehicleController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping
    public String getAllVehicles(Model model) {
        List<Vehicle> vehicles = adminService.getAllVehicles();
        model.addAttribute("vehicles", vehicles);
        return "admin/admin-vehicle-list";
    }

    @PostMapping("/delete")
    public String deleteVehicle(@RequestParam("id") Long id) {
        adminService.deleteVehicle(id);
        return "redirect:/admin/vehicles";
    }

}

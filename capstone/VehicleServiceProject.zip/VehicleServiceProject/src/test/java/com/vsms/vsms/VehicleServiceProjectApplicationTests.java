package com.vsms.vsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleServiceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
